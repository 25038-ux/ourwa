#!/usr/bin/env bash
# Jinan — construire le .ipa (App Store) sur un Mac avec Xcode et Flutter.
# Une fois, dans Xcode (open ios/Runner.xcworkspace) → Runner → Signing & Capabilities :
#   l'équipe Apple (Team), identifiant mr.jinan.parent ; + Push Notifications.
set -euo pipefail
cd "$(dirname "$0")"
flutter pub get
( cd ios && pod install )
flutter build ipa --release --export-method app-store \
  '--dart-define=API_URL=https://api.ecole-jinan.com' \
  '--dart-define=WEB_URL=https://ecole-jinan.com' \
  '--dart-define=BRAND_NAME=Jinan' \
  '--dart-define=BRAND_NAME_AR=جنان'
echo "✓ build/ios/ipa/*.ipa → Transporter (App Store Connect)"
